<!DOCTYPE html>
<html lang="en">
<head>
	<title>Question 2</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<?php
	include_once('nav_bar.php');
?>

<h1>Question 2</h1>

<div class="accordion" id="myAccordion">
    <div class="accordion-item">
        <h2 class="accordion-header" id="headingOne">
            <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseOne">1. What are programming controls and design structures?</button>									
        </h2>
        <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
            <div class="card-body">
                <p>Program control is how a program makes decisions / organizes its activities based on the outcome of a prior operation or user input.<br>(Lutus, 2023)<br>Structured design breaks a system down into functional modules. Each module has its own inputs, processing and outputs.<br>(Morgan, 2003)</p>
            </div>
        </div>
    </div>
    <div class="accordion-item">
        <h2 class="accordion-header" id="headingTwo">
            <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseTwo">2. What are website testing procedures?</button>
        </h2>
        <div id="collapseTwo" class="accordion-collapse collapse collapse" data-bs-parent="#myAccordion">
            <div class="card-body">
                <p>Functional, Usability, Interface, Compatibility, Performace and Security testing. <br>(Vogels, 2022)<br>You can also test out your website on other platforms such as mobile and on other browsers such as Opera.</p>
            </div>
        </div>
    </div>
    <div class="accordion-item">
        <h2 class="accordion-header" id="headingThree">
            <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseThree">3. What are website debugging methods?</button>                     
        </h2>
        <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
            <div class="card-body">
                <p>You can use a tool such as "Weinre" that will specifically allow you to debug your website. You can also put breakpoints in your code to show you when something is happening. You can also print out information to the console to help with the debugging process.</p>
            </div>
        </div>
    </div>
<div class="accordion-item">
        <h2 class="accordion-header" id="headingFour">
            <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseFour">4. What are website coding techniques?</button>                     
        </h2>
        <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
            <div class="card-body">
                <p>When coding make sure to indent your code. When using the same block of code on each page make sure to use the "insert_once()" function. Make sure to keep the "Head" and "Body" seperate from each other. You can use bootstrap for CSS and other components.</p>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>
</html>