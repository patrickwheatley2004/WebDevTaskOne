<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a href="#" class="navbar-brand">Task One</a>
        <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav">
                <a href="index.php" class="nav-item nav-link">Home</a>
                <a href="question1.php" class="nav-item nav-link">Question 1</a>
            	<a href="question2.php" class="nav-item nav-link">Question 2</a>
            	<a href="question3.php" class="nav-item nav-link">Question 3</a>
                <a href="question4.php" class="nav-item nav-link">Question 4</a>
            </div>
            <div class="navbar-nav ms-auto">
                <a href="contact.php" class="nav-item nav-link">Contact</a>
            </div>
        </div>
    </div>
</nav>