<!DOCTYPE html>
<html lang="en">
<head>
	<title>Question 1</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<?php
	include_once('nav_bar.php');
?>

<h1>Question 1</h1>

<div class="accordion" id="myAccordion">
    <div class="accordion-item">
        <h2 class="accordion-header" id="headingOne">
            <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseOne">1. What are the principles of analysis and design?</button>									
        </h2>
        <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
            <div class="card-body">
                <p>Contrast, Balance, Emphasis, Proportion, Hierarchy, Repetition, Rhythm, Pattern, White Space, Movement, Variety and Unity.</p>
            </div>
        </div>
    </div>
    <div class="accordion-item">
        <h2 class="accordion-header" id="headingTwo">
            <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseTwo">2. What are website architectural requirements?</button>
        </h2>
        <div id="collapseTwo" class="accordion-collapse collapse collapse" data-bs-parent="#myAccordion">
            <div class="card-body">
                <p>Usability, Interaction Design. User Interface Design. Information Design. Web Design. Graphic Design. Content Strategy. <br>(Koh, 2016)</p>
            </div>
        </div>
    </div>
    <div class="accordion-item">
        <h2 class="accordion-header" id="headingThree">
            <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseThree">3. What are website design structures, including hierarchy and navigation design?</button>                     
        </h2>
        <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
            <div class="card-body">
                <p>Website design structures include: Sequences, Hierarchies and Webs.</p>
            </div>
        </div>
    </div>
<div class="accordion-item">
        <h2 class="accordion-header" id="headingFour">
            <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseFour">4. What are user-interface design requirements and production processes?</button>                     
        </h2>
        <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
            <div class="card-body">
                <p>The website UI must have a logical flow to it. The colours on the website must also work together via contrast and balance. The UI shouldn't be cluttered and everything should be placed correctly. You also can't overwhelm the user with ads and pop ups.
Understand the customer and what they want, research, draft your UI, design your UI, put it into a website, reflect on the design and improve. <br>(6 Steps of UX/UI Design Process, 2019)</p>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>
</html>