<!DOCTYPE html>
<html lang="en">
<head>
	<title>Question 4</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<?php
	include_once('nav_bar.php');
?>

<h1>Question 4</h1> <br>
<h4>Provide a definition for the following types of technologies!</h4>

<div class="accordion" id="myAccordion">
    <div class="accordion-item">
        <h2 class="accordion-header" id="headingOne">
            <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseOne">1. The three major programming control structures.</button>									
        </h2>
        <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
            <div class="card-body">
                <p>Sequential - Reads the code in order. <br>Selection - Used for making decisions such as an If Statement. <br>Repetition - Used for looping such as a While Loop.</p>
            </div>
        </div>
    </div>
    <div class="accordion-item">
        <h2 class="accordion-header" id="headingTwo">
            <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseTwo">2. Hypertext markup language (HTML) and markup languages.</button>
        </h2>
        <div id="collapseTwo" class="accordion-collapse collapse collapse" data-bs-parent="#myAccordion">
            <div class="card-body">
                <p>HTML is a markup language which uses tags. Markup languages descbribe the structure of a web page.</p>
            </div>
        </div>
    </div>
    <div class="accordion-item">
        <h2 class="accordion-header" id="headingThree">
            <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseThree">3. Cascading style sheets (CSS).</button>                     
        </h2>
        <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
            <div class="card-body">
                <p>CSS is a style sheet language which describes the presentation of a website. It allows you to customize font, colours, images and more. CSS is paired with a markup language such as HTML or XML.</p>
            </div>
        </div>
    </div>
<div class="accordion-item">
        <h2 class="accordion-header" id="headingFour">
            <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseFour">4. Syntaxes and uses of programming languages.</button>                     
        </h2>
        <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
            <div class="card-body">
                <p>Syntax is what defines the rules of a programming language. For example definining an Integer type variable in C# you would write "int number = 5;". In this instance "int" is the syntax. Programming languages help the user talk to the machine in English or other human speaking languages without having to write in binary. A compiler converts the code written to binary for the machine to read, understand and execute. </p>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>
</html>